# LTF_MedBay
# Adds a Faster than light medbay building to Rimworld
# Tends fresh wounds and regenerates non missing body/bionic body parts
